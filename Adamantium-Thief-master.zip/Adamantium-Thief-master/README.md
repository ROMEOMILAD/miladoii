# :unlock: Adamantium-Thief
Get chromium browsers: passwords, credit cards, history, cookies, bookmarks.  
Chrome 80 > is supported!  

# :herb: Examples:  

### :key: Get passwords from browsers:
``` batch
Stealer.exe PASSWORDS
```
<p align="center">
  <img src="images/passwords.gif"/>
</p>

### :credit_card: Get credit cards from browsers:
``` batch
Stealer.exe CREDIT_CARDS
```
<p align="center">
  <img src="images/credit_cards.gif"/>
</p>

### :clock9: Get history from browsers:
``` batch
Stealer.exe HISTORY
```
<p align="center">
  <img src="images/history.gif"/>
</p>

### :bookmark_tabs: Get bookmarks from browsers:
``` batch
Stealer.exe BOOKMARKS
```
<p align="center">
  <img src="images/bookmarks.gif"/>
</p>

### :cookie: Get cookies from browsers:
``` batch
Stealer.exe COOKIES
```
<p align="center">
  <img src="images/cookies.gif"/>
</p>


# :globe_with_meridians: Browsers list:
* Google Chrome
* Opera
* Chromium
* Brave-Browser
* Epic Privacy Browser
* Amigo
* Vivaldi
* Orbitum
* Atom
* Kometa
* Comodo Dragon
* Torch
* Slimjet
* 360Browser
* Maxthon3
* K-Melon
* Sputnik
* Nichrome
* CocCoc Browser
* Uran
* Chromodo
* Yandex (old)
